HOPEFUL HEDGEHOG - GODOT 4 PROJECT (V2 - WITH SPIKY BROWN BALL & SHOOTING STAR TRAIL)
=====================================================================================
How to open and play:
1. Extract this ZIP file to a folder on your computer.
2. Open Godot Engine 4 (4.2 or newer).
3. Click the 'Import' button in the Godot Project Manager.
4. Browse to the extracted 'HopefulHedgehog' folder, select 'project.godot', and click 'Import & Edit'.
5. Once the editor opens, press F5 (or click the Play ▶ button in the top-right corner) to play!
6. Press SPACEBAR or LEFT MOUSE CLICK to jump and curl into a brown spiky ball.
7. Every 1200 pixels travelled, your hedgehog transforms into a spinning brown spiky shooting star with a glowing star trail!
