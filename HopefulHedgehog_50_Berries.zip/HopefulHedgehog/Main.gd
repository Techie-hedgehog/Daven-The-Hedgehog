extends Node2D

@export var obstacle_scene : PackedScene = preload("res://Obstacle.tscn")
@export var berry_scene : PackedScene = preload("res://Berry.tscn")
@export var star_tex : Texture2D = preload("res://star.png")

const TARGET_BERRIES : int = 50
const DISTANCE_FOR_SUPERPOWER : float = 1200.0

var berries_collected : int = 0
var lives : int = 3
var distance_since_last_dash : float = 0.0
var game_ended : bool = false

@onready var bg1 : Sprite2D = $Background1
@onready var bg2 : Sprite2D = $Background2
@onready var player = $Player
@onready var score_label : Label = $UI/ScoreLabel
@onready var dash_label : Label = $UI/DashLabel
@onready var power_bar : ProgressBar = $UI/PowerBar
@onready var heart1 : TextureRect = $UI/HeartsContainer/Heart1
@onready var heart2 : TextureRect = $UI/HeartsContainer/Heart2
@onready var heart3 : TextureRect = $UI/HeartsContainer/Heart3
@onready var end_panel : Panel = $UI/EndPanel
@onready var message_label : Label = $UI/EndPanel/MessageLabel
@onready var restart_button : Button = $UI/EndPanel/RestartButton
@onready var obstacle_timer : Timer = $ObstacleTimer
@onready var berry_timer : Timer = $BerryTimer
@onready var berry_sfx : AudioStreamPlayer = $BerrySFX
@onready var hit_sfx : AudioStreamPlayer = $HitSFX

func _ready() -> void:
	end_panel.visible = false
	update_ui()
	obstacle_timer.timeout.connect(_spawn_obstacle)
	berry_timer.timeout.connect(_spawn_berry)
	restart_button.pressed.connect(_restart_game)

func _process(delta: float) -> void:
	if game_ended:
		return

	var bg_speed : float = 160.0 if player.is_dashing else 55.0
	bg1.position.x -= bg_speed * delta
	bg2.position.x -= bg_speed * delta
	if bg1.position.x <= -576.0:
		bg1.position.x = bg2.position.x + 1152.0
	if bg2.position.x <= -576.0:
		bg2.position.x = bg1.position.x + 1152.0

	if not player.is_dashing:
		distance_since_last_dash += 250.0 * delta
		var pct : float = clamp((distance_since_last_dash / DISTANCE_FOR_SUPERPOWER) * 100.0, 0.0, 100.0)
		power_bar.value = pct
		dash_label.text = "Shooting Star Ball Power: " + str(int(pct)) + "%"
		if distance_since_last_dash >= DISTANCE_FOR_SUPERPOWER:
			distance_since_last_dash = 0.0
			player.activate_super_dash()
	else:
		power_bar.value = 100.0
		dash_label.text = "🌠 SHOOTING STAR BALL ACTIVE! 🌠"

func is_player_dashing() -> bool:
	return player.is_dashing

func _spawn_obstacle() -> void:
	if game_ended:
		return
	var obs = obstacle_scene.instantiate()
	var random_y = randf_range(210.0, 430.0)
	obs.position = Vector2(1250.0, random_y)
	add_child(obs)

func _spawn_berry() -> void:
	if game_ended:
		return
	var berry = berry_scene.instantiate()
	var random_y = randf_range(110.0, 520.0)
	berry.position = Vector2(1250.0, random_y)
	add_child(berry)

func collect_berry(pickup_pos: Vector2 = Vector2.ZERO) -> void:
	if game_ended:
		return
	berries_collected += 1
	berry_sfx.play()
	update_ui()
	
	if pickup_pos != Vector2.ZERO:
		_spawn_floating_text("+1 Berry!", pickup_pos, Color(1.0, 0.95, 0.4))
	
	if berries_collected >= TARGET_BERRIES:
		trigger_game_completed()

func on_obstacle_smashed(smash_pos: Vector2) -> void:
	berry_sfx.play()
	_spawn_floating_text("SMASH!", smash_pos, Color(1.0, 0.85, 0.25))

func _spawn_floating_text(txt: String, pos: Vector2, col: Color) -> void:
	var lbl = Label.new()
	lbl.text = txt
	lbl.position = pos + Vector2(-30, -20)
	lbl.add_theme_font_size_override("font_size", 20)
	lbl.modulate = col
	add_child(lbl)
	var tw = lbl.create_tween()
	tw.set_parallel(true)
	tw.tween_property(lbl, "position:y", lbl.position.y - 55.0, 0.55)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.55)
	tw.chain().tween_callback(lbl.queue_free)

func on_player_hit() -> void:
	if game_ended or player.is_invincible:
		return
		
	lives -= 1
	hit_sfx.play()
	update_ui()
	
	if lives > 0:
		player.respawn(Vector2(200.0, 300.0))
	else:
		trigger_game_over()

func update_ui() -> void:
	score_label.text = "Berries: " + str(berries_collected) + " / " + str(TARGET_BERRIES)
	heart1.visible = (lives >= 1)
	heart2.visible = (lives >= 2)
	heart3.visible = (lives >= 3)

func trigger_game_over() -> void:
	game_ended = true
	player.set_physics_process(false)
	end_panel.visible = true
	
	message_label.text = (
		"WELL DONE!\n\n" +
		"You collected " + str(berries_collected) + " berries!\n\n" +
		"Remember: Even when we fall three times, our journey matters.\n" +
		"Ups and downs come in everybody's life—every attempt makes you stronger.\n" +
		"Take a deep breath and try again!"
	)

func trigger_game_completed() -> void:
	game_ended = true
	player.set_physics_process(false)
	end_panel.visible = true
	
	message_label.text = (
		"GAME COMPLETED! (50 / 50 BERRIES)\n\n" +
		"A Life Lesson For Your Journey:\n" +
		"Just like this little hedgehog jumping between sharp icicles and tall trees, " +
		"ups and downs come in everybody's life. Sometimes you stumble, and sometimes the " +
		"winter feels cold and heavy.\n\n" +
		"But never lose hope. Even in your hardest moments, you have a superpower inside you " +
		"to curl up, shine like a shooting star, and roll right through the toughest obstacles. " +
		"Keep going one berry and one day at a time—brighter skies are always ahead, " +
		"and you are stronger than you know!"
	)

func _restart_game() -> void:
	get_tree().reload_current_scene()
