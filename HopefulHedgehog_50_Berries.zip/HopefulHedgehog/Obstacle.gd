extends Area2D

var base_speed : float = 250.0

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	var main = get_parent()
	var speed_multiplier : float = 2.7 if main.is_player_dashing() else 1.0
	position.x -= base_speed * speed_multiplier * delta

	if position.x < -150.0:
		queue_free()

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		if body.is_dashing:
			get_parent().on_obstacle_smashed(global_position)
			queue_free()
		elif not body.is_invincible:
			get_parent().on_player_hit()
