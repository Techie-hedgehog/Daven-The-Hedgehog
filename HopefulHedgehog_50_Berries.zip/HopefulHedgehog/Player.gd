extends CharacterBody2D

const GRAVITY : float = 950.0
const JUMP_FORCE : float = -360.0
const ROLL_SPEED : float = 22.0
const DASH_DURATION : float = 1.65

var is_rolling : bool = false
var is_dashing : bool = false
var is_invincible : bool = false
var dash_timer : float = 0.0
var ghost_timer : float = 0.0
var start_x : float = 200.0

var normal_tex : Texture2D = preload("res://hedgehog.png")
var ball_tex : Texture2D = preload("res://hedgehog_ball.png")

@onready var sprite : Sprite2D = $Sprite2D
@onready var star_trail : CPUParticles2D = $ShootingStarTrail
@onready var jump_sfx : AudioStreamPlayer = $JumpSFX
@onready var dash_sfx : AudioStreamPlayer = $DashSFX

func _ready() -> void:
	start_x = position.x
	add_to_group("player")
	set_ball_form(false)
	star_trail.emitting = false

func set_ball_form(as_ball: bool) -> void:
	if as_ball:
		sprite.texture = ball_tex
		sprite.scale = Vector2(0.27, 0.27)
	else:
		sprite.texture = normal_tex
		sprite.scale = Vector2(0.09, 0.09)

func _physics_process(delta: float) -> void:
	if is_dashing:
		dash_timer -= delta
		ghost_timer -= delta
		velocity.y = 0.0
		set_ball_form(true)
		star_trail.emitting = true
		sprite.rotation += ROLL_SPEED * 3.0 * delta
		
		if ghost_timer <= 0.0:
			ghost_timer = 0.045
			_spawn_shooting_star_afterimage()
			
		if dash_timer <= 0.0:
			end_dash()
	else:
		velocity.y += GRAVITY * delta
		position.x = move_toward(position.x, start_x, 200.0 * delta)
		
		if Input.is_action_just_pressed("jump"):
			velocity.y = JUMP_FORCE
			is_rolling = true
			set_ball_form(true)
			jump_sfx.play()
			var tw = create_tween()
			sprite.scale = Vector2(0.33, 0.22)
			tw.tween_property(sprite, "scale", Vector2(0.27, 0.27), 0.14)
		
		if is_rolling and velocity.y < 95.0:
			sprite.rotation += ROLL_SPEED * delta
		else:
			if is_rolling:
				is_rolling = false
				set_ball_form(false)
			sprite.rotation = lerp_angle(sprite.rotation, 0.0, 10.0 * delta)

	move_and_slide()

	var screen_height = get_viewport_rect().size.y
	if position.y > screen_height - 20.0 or position.y < -40.0:
		get_parent().on_player_hit()

func _spawn_shooting_star_afterimage() -> void:
	var ghost = Sprite2D.new()
	ghost.texture = ball_tex
	ghost.global_position = global_position
	ghost.rotation = sprite.rotation
	ghost.scale = sprite.scale * 0.95
	ghost.modulate = Color(1.0, 0.9, 0.35, 0.65)
	get_parent().add_child(ghost)
	var tw = ghost.create_tween()
	tw.set_parallel(true)
	tw.tween_property(ghost, "position:x", ghost.position.x - 140.0, 0.25)
	tw.tween_property(ghost, "scale", Vector2(0.05, 0.05), 0.25)
	tw.tween_property(ghost, "modulate:a", 0.0, 0.25)
	tw.chain().tween_callback(ghost.queue_free)

func activate_super_dash() -> void:
	if is_dashing:
		return
	is_dashing = true
	is_invincible = true
	dash_timer = DASH_DURATION
	set_ball_form(true)
	star_trail.emitting = true
	dash_sfx.play()
	modulate = Color(1.28, 1.22, 0.78, 1.0)

func end_dash() -> void:
	is_dashing = false
	star_trail.emitting = false
	set_ball_form(false)
	await get_tree().create_timer(1.0).timeout
	if not is_dashing:
		is_invincible = false
		modulate = Color(1.0, 1.0, 1.0, 1.0)

func respawn(spawn_pos: Vector2) -> void:
	position = spawn_pos
	velocity = Vector2.ZERO
	is_dashing = false
	is_rolling = false
	star_trail.emitting = false
	set_ball_form(false)
	is_invincible = true
	modulate = Color(1.0, 1.0, 1.0, 0.5)
	await get_tree().create_timer(1.5).timeout
	if not is_dashing:
		is_invincible = false
		modulate = Color(1.0, 1.0, 1.0, 1.0)
