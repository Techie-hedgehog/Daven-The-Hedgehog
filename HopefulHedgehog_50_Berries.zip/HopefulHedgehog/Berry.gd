extends Area2D

var base_speed : float = 250.0
var time_alive : float = 0.0
var start_y : float = 0.0

func _ready() -> void:
	start_y = position.y
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	time_alive += delta
	var main = get_parent()
	var speed_multiplier : float = 2.7 if main.is_player_dashing() else 1.0
	position.x -= base_speed * speed_multiplier * delta
	position.y = start_y + sin(time_alive * 5.0) * 8.0
	
	if position.x < -100.0:
		queue_free()

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		get_parent().collect_berry(global_position)
		queue_free()
